---
name: "🤔 Request new features"  
about: There are some ideas or demands want to discuss with the official and hope to be implemented in the future.    
title: ''  
labels: kind/features    
assignees: ''  
---

**Feature description**
<!-- Clear and direct description of the functionality of the currently submitted or proposed feature -->

**Your Feature**
<!-- Describe the idea or process of implementing the current feature. Of course, you can also paste the URL address of your Pull Request. -->
<!-- When submitting features, you need to complete the corresponding doc/tests/examples to facilitate verification by reviewers. -->
